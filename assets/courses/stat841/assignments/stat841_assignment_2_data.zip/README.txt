STAT 841 / CM 763 - Assignment 2 - Fall 2026
Student data package

Extract this ZIP before working. Use relative file paths in your scripts.
Keep the supplied filenames and observation order unchanged.
Questions 1, 2, and 4 do not need supplied data files.
Input files for Questions 3, 5, and 6 are listed below.

DATA LAYOUT
The observation files use columns for observations. The first row gives IDs,
and the first column gives row names. Rows y, x1, x2 contain the labels and
two features. Reading x1 and x2 gives X with shape 2 by n; do not transpose X.
The label vector has length n. Labels are -1 and +1.
Metadata tables (model_info and hard_summary) instead have one row per model.
Test labels are supplied for evaluation only. Do not use them to fit a model,
choose a penalty/width, or adjust solver settings.

QUESTION 3
Q3_train.csv: 60 observations, IDs linear_train001 through linear_train060.
Q3_test.csv: 200 observations, IDs linear_test001 through linear_test200.
The training set is strictly linearly separable. Plot limits [-2.8,2.8] along
both axes include all training observations. Fit the three models specified
in the assignment: standard, penalized, and translated. For the translated
model only, use z = x - a with a = (-2,2) for both training and test inputs.
Plot every model back in the original coordinates. No extra data file is
needed for this translation.

QUESTION 5
Q5_train.csv: 40 observations, IDs train001 through train040.
Q5_test.csv: 200 observations, IDs test001 through test200.
Q5_models.csv: 40 coefficient columns aligned exactly with Q5_train.csv.
Its four row names are:
  alpha_quadratic
  alpha_gaussian_02
  alpha_gaussian_07
  alpha_gaussian_14
The entries are raw alpha multipliers. Multiply each by its training label
exactly once when computing the prediction score.
Q5_model_info.csv: four rows, columns model,kernel,h,beta0.
Its model names are quadratic,gaussian_02,gaussian_07,gaussian_14.
The quadratic row has a blank h; Gaussian widths are 0.2,0.7,1.4.
Use these fitted coefficients and intercepts unchanged. No fitting is needed.
Gaussian kernel: exp(-squared_distance / h^2), without a factor of 2.
Scores are not probabilities. Predict +1 for a score of zero.

QUESTION 6
Q6_train.csv: 40 observations, IDs train001 through train040.
Q6_test.csv: 200 observations, IDs test001 through test200.
The training labels at train004,train009,train024,train029 have ALREADY been
reversed. Do not reverse them again. Evaluate training error against the y
row supplied in Q6_train.csv and test error against Q6_test.csv.
Q6_hard_summary.csv: supplied hard-margin comparison, one model row.
Columns: model,h,train_error,test_error,support_count.
This model was fitted to Q6_train.csv, including the altered labels, using
the Gaussian kernel with h=0.7. Copy its errors and support count into the
reference row of your results table. Leave gamma,free_count,beta0,slack_sum,
and diagnostics blank for that row; they are not supplied or required.
No hard-margin model needs to be fitted for Question 6.
Q6_hard_grid.csv: 6400 columns, with rows x1,x2,score.
There are 80 equally spaced x1 values and 80 equally spaced x2 values,
each covering [-2.2,2.2]. x1 varies fastest: the first 80 columns have the
smallest x2 and increasing x1, then the next x2 value is used.
Evaluate your three soft-margin models at these same coordinates. The score
row is supplied only for the hard-margin reference panel.

GRID RESHAPING
With NumPy meshgrid-style coordinates, use score.reshape(80,80).
With MATLAB meshgrid-style coordinates, use reshape(score,80,80).' .
With R contour(x_axis,y_axis,z), use matrix(score,nrow=80,ncol=80), because
R contour expects its first z dimension to correspond to x_axis.
Alternatively, plot directly from the supplied coordinate pairs.

READING AN OBSERVATION FILE
The following examples only load data; they do not implement any method.

Python (standard csv module and NumPy):
  import csv
  import numpy as np
  with open('Q3_train.csv', newline='') as handle:
      rows = list(csv.reader(handle))
  ids = rows[0][1:]
  values = {row[0]: np.asarray(row[1:], dtype=float) for row in rows[1:]}
  X = np.vstack([values['x1'], values['x2']])
  y = values['y']

R:
  tab <- read.csv('Q3_train.csv', row.names=1, check.names=FALSE)
  ids <- colnames(tab)
  X <- as.matrix(tab[c('x1','x2'), , drop=FALSE])
  y <- as.numeric(as.matrix(tab['y', , drop=FALSE]))

MATLAB:
  T = readtable('Q3_train.csv', 'ReadRowNames', true, ...
                'VariableNamingRule', 'preserve');
  ids = T.Properties.VariableNames;
  X = table2array(T({'x1','x2'}, :));
  y = table2array(T('y', :)).';

RUNNING AND SUBMITTING
Each main script (Q1, Q3, Q5, Q6) must run without running any other question.
Shared helpers are allowed if included. Include required input files and
your own results CSVs in WatIAM_A2.zip, along with a short run README.
Q2 and Q4 need written answers only.
