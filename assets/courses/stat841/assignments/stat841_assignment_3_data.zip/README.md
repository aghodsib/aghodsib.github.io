# STAT 841 / CM 763 Assignment 3 data

All supplied CSV input files contain numbers only, with no header or row-name column. Each observation is a column. The CSV files students submit as results, in contrast, must have the headers specified in the assignment.

| Input file | Rows and columns | Contents |
| --- | --- | --- |
| CNN_train.csv | 145 by 400 | Rows 1–144: one flattened image per column. Row 145: label, -1 or +1. |
| CNN_test.csv | 145 by 200 | Same format as CNN_train.csv. |
| CNN_initial.csv | 45 by 1 | Initial parameters shared by both CNNs. See README_CNN.md for ordering. |
| Ensemble_train.csv | 10 by 320 | Rows 1–8: features. Row 9: observed labels. Row 10: reversal flags. |
| Ensemble_test.csv | 9 by 1,000 | Rows 1–8: features. Row 9: labels. |
| Q5_stumps.csv | 3 by 112 | Each column contains feature index, threshold, and polarity. |

Use only the designated feature rows as predictors. Transpose the feature matrix when calling an API that expects observations in rows. Labels in every supplied dataset are -1 or +1. A framework using 0/1 binary targets should receive (y+1)/2; report predictions and errors using the original labels.

## Question 2

Read README_CNN.md for image ordering, initialization, circular indexing, and the optional loaders. The loaders only handle data and array conventions. Construct and train the networks specified in the PDF using a neural-network library and automatic differentiation if desired. There is no requirement to implement backpropagation manually.

Use the prescribed full-batch gradient descent settings. An optimizer's defaults may introduce momentum, weight decay, or other changes; disable these. Load the same initial parameter file separately for each stride. Do not initialize the second model from the first model's trained weights.

## Question 4

Exactly 32 observed training labels were reversed during data construction. Row 10 identifies these columns for Question 5's diagnostic. Do not use that row to fit either question's model, correct labels, remove observations, or choose settings.

Your code draws each bootstrap sample and fits one base tree on that already sampled data. It then combines hard class votes. R's ranger package is explicitly permitted for this single-tree use. Use the per-node feature parameter m=8 for the full-data tree and bagging, and m=2 for the random forest.

Recommended single-tree configurations:

- Python, sklearn.tree.DecisionTreeClassifier: criterion="gini", max_features=m, min_samples_leaf=5, max_depth=None, ccp_alpha=0.0. Pass a fresh integer random_state for each successive tree in an ensemble.
- R, ranger::ranger: num.trees=1, mtry=m, splitrule="gini", probability=TRUE, min.node.size=1, min.bucket=5, max.depth=0, replace=FALSE, sample.fraction=1, oob.error=FALSE. Use a factor response and pass a fresh positive integer seed for each successive tree. These settings prevent a second internal resample.
- MATLAB, fitctree: SplitCriterion='gdi', NumVariablesToSample=m, MinLeafSize=5, MinParentSize=10, MaxNumSplits=319, MergeLeaves='off', Prune='off', Reproducible=true. Generate and set a new tree seed for each successive tree; manage the main bootstrap generator separately so resetting a tree stream cannot reset the bootstrap sequence.

For each individual tree, find its probability column labelled +1 and threshold that probability at 0.5, with equality predicting +1. Do not use scikit-learn's predict() method for this step, since its leaf-tie rule can predict -1. R and MATLAB may use their prediction APIs to obtain probabilities; convert those probabilities to hard labels before combining trees.

Using ranger for the full-data tree, bagging, and the random forest keeps the base learner consistent in R. rpart and tree do not supply the required per-node feature sampling for the random-forest arm.

Libraries differ in split ties and search details. For example, scikit-learn may inspect extra features when necessary to find a valid split. Document your library/version and settings. Exact results need not agree across languages or seeds.

Configuration references: [scikit-learn](https://scikit-learn.org/stable/modules/generated/sklearn.tree.DecisionTreeClassifier.html), [ranger](https://imbs-hl.github.io/ranger/reference/ranger.html), [rpart](https://stat.ethz.ch/R-manual/R-devel/library/rpart/html/rpart.control.html), [MATLAB](https://www.mathworks.com/help/stats/fitctree.html).

## Question 5

Use double precision for weights and weighted-error calculations. In each stump column (j,s,p), predict p when feature j is at least s, and -p otherwise. Feature indices are one-based. Python code must subtract one before using j as an array index.

Candidates are ordered by increasing j, increasing threshold from {-1.5,-1,-0.5,0,0.5,1,1.5}, then polarity +1 followed by -1. The first columns are (1,-1.5,+1), (1,-1.5,-1), (1,-1,+1); column 15 is (2,-1.5,+1).

At each round, find the minimum weighted error over all 112 candidates. Among candidates with error at most that minimum plus 1e-12, choose the smallest column index. Use that selected stump's actual weighted error in the AdaBoost update.

The flag-weight diagnostic uses the weights after the current round's update. The flag itself must not affect stump selection or the updates.
