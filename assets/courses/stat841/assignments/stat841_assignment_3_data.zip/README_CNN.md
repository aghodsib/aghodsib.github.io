# Question 2: CNN data and initialization

All three CSV files contain numbers only, with no header or row-label column.

| File | Shape | Contents |
| --- | --- | --- |
| CNN_train.csv | 145 rows, 400 columns | One training image per column. Rows 1 to 144 are pixels; row 145 is the label. |
| CNN_test.csv | 145 rows, 200 columns | One test image per column, in the same format. |
| CNN_initial.csv | 45 rows, 1 column | The prescribed initial parameters for both networks. |

Each image is 12 by 12. Pixel values lie between zero and one. The labels are +1 for a vertical bar and -1 for a horizontal bar. A circular translation preserves the label.

## Image layout

The first 12 entries of a data column are image column 1, read from top to bottom; the next 12 are image column 2. Thus image entry at row u and column v is data row u + 12(v - 1), using one-based indices.

The optional loaders load the files and reshape the supplied values. They do not construct or train a network.

- Python: load_cnn.py returns images with shape (n, 12, 12), and kernels with shape (4, 3, 3). It uses NumPy's column-major reshape order explicitly.
- R: load_cnn.R returns images with dimensions (12, 12, n), and kernels with dimensions (3, 3, 4).
- MATLAB: load_cnn.m returns images with dimensions (12, 12, n), and kernels with dimensions (3, 3, 4).

Adapt these arrays to your chosen framework's batch and channel conventions. For example, PyTorch's one-channel input has shape (n, 1, 12, 12), while a channels-last input has shape (n, 12, 12, 1). A framework may expect kernel axes in a different order. Preserve the kernel's row and column directions when permuting axes.

## Initial parameter layout

| Rows | Parameters |
| --- | --- |
| 1 to 9 | Kernel 1, a 3 by 3 matrix in column-major order |
| 10 to 18 | Kernel 2, in the same order |
| 19 to 27 | Kernel 3, in the same order |
| 28 to 36 | Kernel 4, in the same order |
| 37 to 40 | The four channel biases, added before ReLU |
| 41 to 44 | The four linear readout coefficients |
| 45 | The scalar output bias |

Both stride models start from a separate copy of these same values. Train every parameter, including both kinds of bias. The supplied initialization removes the need to choose a random initialization seed.

## Circular padding and shifts

Use centered circular cross-correlation: each 3 by 3 neighborhood has row and column offsets -1, 0, 1. Wrap an index outside 1 to 12 back into that range. Pad one row and one column on every side by wrapping, then apply valid cross-correlation with the prescribed stride. Do not use a framework's default zero padding or its default "same" padding.

For stride 1, retained centers are every image position. For stride 2, retained row and column centers are 1, 3, 5, 7, 9, 11 in one-based indexing. Apply the bias and ReLU at each retained position, then average all retained positions separately within each channel.

A right shift by q columns moves image column v to column v+q, with circular wrap. It shifts the noise as well as the bar. In Python, for an image batch shaped (n, 12, 12), this is numpy.roll(images, q, axis=2). For R's (12, 12, n) layout, select column indices ((1:12 - q - 1) %% 12) + 1. For MATLAB's layout, use circshift(images, [0 q 0]).

Evaluate shifted test images using the already-trained model. Do not retrain or change their labels.

## Training conventions

The assignment specifies 300 full-batch gradient updates with step size 2.0. Use the mean logistic loss with labels -1 and +1. A binary-cross-entropy-with-logits routine is equivalent when its targets are converted to (y + 1)/2 and its reduction is the mean.

Update all parameters simultaneously using gradients at the current parameter values. Use ordinary gradient descent without momentum, adaptive learning rates, weight decay, minibatches, augmentation, or early stopping. Define the ReLU derivative at zero to be zero. Standard neural-network libraries and automatic differentiation are permitted.

Record the training loss before any update and after each completed update for the required plot. The final evaluation uses the parameters after update 300. The output is a real-valued score; predict +1 for a nonnegative score and -1 otherwise.

Use the test files only for the prescribed evaluations, not to choose parameters, update counts, or preprocessing. Do not rescale or standardize the supplied pixel values.
