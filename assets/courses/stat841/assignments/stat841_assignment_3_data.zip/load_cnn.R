# Optional data/parameter loader for Assignment 3, Question 2.
load_cnn <- function(data_file, initial_file = "CNN_initial.csv") {
  raw <- as.matrix(read.csv(data_file, header = FALSE, check.names = FALSE))
  if (nrow(raw) != 145L) stop("The image file must have 145 rows.")
  x <- raw[1:144, , drop = FALSE]
  y <- as.numeric(raw[145, ])
  images <- array(x, dim = c(12L, 12L, ncol(x)))
  theta <- as.numeric(as.matrix(read.csv(initial_file, header = FALSE)))
  if (length(theta) != 45L) stop("The initialization file must contain 45 scalars.")
  kernels <- array(theta[1:36], dim = c(3L, 3L, 4L))
  list(X = x, y = y, images = images, kernels = kernels,
       channel_bias = theta[37:40], readout = theta[41:44],
       output_bias = theta[45])
}

