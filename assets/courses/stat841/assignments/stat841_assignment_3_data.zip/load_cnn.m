function data = load_cnn(data_file, initial_file)
% Optional data/parameter loader for Assignment 3, Question 2.
if nargin < 2
    initial_file = 'CNN_initial.csv';
end
raw = readmatrix(data_file);
if size(raw, 1) ~= 145
    error('The image file must have 145 rows.');
end
data.X = raw(1:144, :);
data.y = raw(145, :);
data.images = reshape(data.X, 12, 12, []);
theta = readmatrix(initial_file);
theta = theta(:);
if numel(theta) ~= 45
    error('The initialization file must contain 45 scalars.');
end
data.kernels = reshape(theta(1:36), 3, 3, 4);
data.channel_bias = theta(37:40);
data.readout = theta(41:44);
data.output_bias = theta(45);
end

