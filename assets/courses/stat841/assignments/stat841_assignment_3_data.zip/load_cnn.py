"""Optional data/parameter loader for Assignment 3, Question 2."""
from pathlib import Path
import numpy as np


def load_cnn(data_file, initial_file="CNN_initial.csv"):
    raw = np.loadtxt(Path(data_file), delimiter=",")
    if raw.ndim != 2 or raw.shape[0] != 145:
        raise ValueError("The image file must have 145 rows.")
    x = raw[:144]
    y = raw[144]
    images = np.stack([x[:, i].reshape((12, 12), order="F")
                       for i in range(x.shape[1])])
    theta = np.loadtxt(Path(initial_file), delimiter=",").reshape(-1)
    if theta.size != 45:
        raise ValueError("The initialization file must contain 45 scalars.")
    kernels = np.stack([theta[9*c:9*(c+1)].reshape((3, 3), order="F")
                        for c in range(4)])
    return {"X": x, "y": y, "images": images, "kernels": kernels,
            "channel_bias": theta[36:40].copy(),
            "readout": theta[40:44].copy(), "output_bias": float(theta[44])}

