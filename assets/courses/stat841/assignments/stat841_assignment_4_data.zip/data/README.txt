STAT 841 / CM 763 - Assignment 4
Student data package

All six CSV files contain numbers only, with no header or row-name column.
Use the files unchanged. Classification labels are -1 and +1.

SUBMISSION LAYOUT

Keep the supplied data/ folder beside your three question scripts. Put
your scripts, helpers, README.md and three results CSVs at the top level
of WatIAM_A4.zip. Run each script from that level using relative paths.

FILES AND SHAPES

train.csv              13 rows x 400 columns
validation.csv         13 rows x 160 columns
test.csv               13 rows x 240 columns
triplets.csv           800 rows x 3 columns
U_initial.csv          2 rows x 12 columns
label_permutation.csv  1 row x 400 columns

In train.csv, validation.csv and test.csv, each column is an observation.
Rows 1 through 12 contain features x1 through x12. Row 13 contains the label.
The training set contains 200 observations labelled -1 and 200 labelled +1.
The validation and test sets are also balanced. Keep the training columns in
their supplied order because the triplets and the permutation refer to it.

QUESTION 1: PREPROCESSING AND BASELINES

Estimate feature means and standard deviations from train.csv only. Use
400, not 399, as the divisor for each training feature variance. Every
standard deviation is positive. Apply the same training means and standard
deviations to validation and test features. Do not standardize each split
separately.

For Gaussian Naive Bayes, estimate each class variance using the class
training count as divisor, then replace it by max(variance, 1e-8). Use this
same floor in raw and standardized coordinates. Predict +1 on a score tie.

Choose k separately for raw and standardized k-NN using validation error
among k = 1, 3, 5, 9. Resolve a validation-error tie with the smaller k.
Order equal-distance neighbours by their original training-column index.
A stable sort by distance preserves that order when the input is in
training-column order.
Do not add validation observations to the training set after selecting k.

QUESTION 2: FIXED TRIPLETS AND INITIAL MATRIX

Each row of triplets.csv contains (anchor, positive, negative), in that
order. Entries are 1-based training-column indices between 1 and 400.
The anchor and positive are distinct observations with the same label;
the negative has the opposite label. Python users must subtract 1 before
indexing. Keep all 800 triplets fixed throughout training.

U_initial.csv is the supplied 2 by 12 matrix U_0. Do not transpose it.
Use the training standardization from Question 1. Use the prescribed mean
triplet objective with margin 1, lambda = 0.001, step size 0.05, and exactly
300 full-batch gradient updates. Treat a hinge argument equal to zero as
inactive. The initial objective rounds to 1.095181. The coordinate
perturbations in the finite-difference check preserve the active set.
Begin training again from U_0 after the check. The objective can rise on
individual updates with the prescribed fixed step.
Use fixed k = 5 for the three representation comparisons.

QUESTION 4: RAW CENTERING AND LABEL PERMUTATION

Use raw features. Subtract the original training mean from both training
and test observations. Do not divide by standard deviations.

label_permutation.csv contains each integer from 1 to 400 exactly once.
If its i-th entry is p_i, set shuffled_y[i] = training_y[p_i] in 1-based
indexing. In Python: shuffled_y = training_y[permutation - 1].
Only the label Gram matrix for the shuffled-label SPCA fit uses these
shuffled labels. Keep feature columns in their original order. Use the
original training labels for all three 5-NN classifiers and for all three
reported training HSIC values. The test labels are never shuffled.

Keep one unit-norm leading eigenvector for each method. Use the three
fitting matrices exactly as given, without a covariance divisor. Include
their largest eigenvalues in the results table. Under the written table,
report the absolute cosine for true-label SPCA and the class-mean
difference. Its value is independent of the eigenvector sign.

LOADING THE FILES

From the submission's top level, the following Python example reads the
inputs in data/.

  import numpy as np
  train = np.loadtxt('data/train.csv', delimiter=',')
  X = train[:12, :]
  y = train[12, :]
  triplets = np.loadtxt('data/triplets.csv', delimiter=',', dtype=int) - 1
  U0 = np.loadtxt('data/U_initial.csv', delimiter=',')
  permutation = np.loadtxt('data/label_permutation.csv', delimiter=',',
                           dtype=int).ravel()
  shuffled_y = y[permutation - 1]

In R, use as.matrix(read.csv("data/train.csv", header=FALSE)). The first
12 rows are X and the thirteenth row is y. Keep 1-based indices.

In MATLAB, use readmatrix("data/train.csv"). The first 12 rows are X and
the thirteenth row is y. Keep 1-based indices.

Only Question 1 uses validation data, for the prescribed evaluations and
choice of k.
Use test labels only to calculate the requested final classification errors.
Keep full numeric precision in the results CSVs. In the written work, give
error proportions to five decimal places, Q2 objectives to six decimal
places, and delta and e in scientific notation with three significant
figures (write 0 if exactly zero). Required file names, columns and row
orders are in the assignment PDF.
